## CSS Hover Zoom

A collection of pure CSS-based zoom on hover effects. 

Download the ZIP or clone this folder using the following command:

```
git clone https://github.com/c99rahul/css-hover-zoom.git
```

[Read the full tutorial guide here](https://w3bits.com/css-image-hover-zoom/) to understand the code shared in this repo.